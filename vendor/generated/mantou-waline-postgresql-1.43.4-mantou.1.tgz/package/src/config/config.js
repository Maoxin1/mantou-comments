// Modified 2026-10-05 for the local Mantou PostgreSQL-only derivative.
// Upstream notices are preserved in LICENSE and DERIVATION.md.
const {
  JWT_TOKEN,
  FORBIDDEN_WORDS,
  SECURE_DOMAINS,
  DISABLE_USERAGENT,
  DISABLE_REGION,
  AVATAR_PROXY,
  OAUTH_URL,

  MARKDOWN_CONFIG = '{}',
  MARKDOWN_HIGHLIGHT,
  MARKDOWN_EMOJI,
  MARKDOWN_SUB,
  MARKDOWN_SUP,
  // mathjax will be the default option for tex
  MARKDOWN_TEX = 'mathjax',
  MARKDOWN_MATHJAX = '{}',
  MARKDOWN_KATEX = '{}',

  MAIL_SUBJECT,
  MAIL_TEMPLATE,
  MAIL_SUBJECT_ADMIN,
  MAIL_TEMPLATE_ADMIN,
  QQ_TEMPLATE,
  TG_TEMPLATE,
  WX_TEMPLATE,
  SC_TEMPLATE,
  DISCORD_TEMPLATE,
  LARK_TEMPLATE,

  LEVELS,
  COMMENT_AUDIT,
} = process.env;

const storage = 'postgresql';
const jwtKey = JWT_TOKEN;
if (!jwtKey) throw new Error('An explicit JWT_TOKEN is required; database-secret fallback is disabled');

const forbiddenWords = FORBIDDEN_WORDS ? FORBIDDEN_WORDS.split(/\s*,\s*/u) : [];

const isFalse = (content) => content && ['0', 'false'].includes(content.toLowerCase());

const markdown = {
  config: JSON.parse(MARKDOWN_CONFIG),
  plugin: {
    emoji: !isFalse(MARKDOWN_EMOJI),
    sub: !isFalse(MARKDOWN_SUB),
    sup: !isFalse(MARKDOWN_SUP),
    tex: isFalse(MARKDOWN_TEX) ? false : MARKDOWN_TEX,
    mathjax: JSON.parse(MARKDOWN_MATHJAX),
    katex: JSON.parse(MARKDOWN_KATEX),
  },
};

if (isFalse(MARKDOWN_HIGHLIGHT)) markdown.config.highlight = false;

let avatarProxy = '';

if (AVATAR_PROXY) {
  avatarProxy = isFalse(AVATAR_PROXY) ? '' : AVATAR_PROXY;
}

const oauthUrl = OAUTH_URL || 'https://oauth.lithub.cc';

module.exports = {
  workers: 1,
  storage,
  jwtKey,
  forbiddenWords,
  disallowIPList: [],
  secureDomains: SECURE_DOMAINS ? SECURE_DOMAINS.split(/\s*,\s*/u) : null,
  disableUserAgent: DISABLE_USERAGENT && !isFalse(DISABLE_USERAGENT),
  disableRegion: DISABLE_REGION && !isFalse(DISABLE_REGION),
  levels: !LEVELS || isFalse(LEVELS) ? false : LEVELS.split(/\s*,\s*/u).map(Number),

  audit: COMMENT_AUDIT && !isFalse(COMMENT_AUDIT),
  avatarProxy,
  oauthUrl,
  markdown,
  mailSubject: MAIL_SUBJECT,
  mailTemplate: MAIL_TEMPLATE,
  mailSubjectAdmin: MAIL_SUBJECT_ADMIN,
  mailTemplateAdmin: MAIL_TEMPLATE_ADMIN,
  QQTemplate: QQ_TEMPLATE,
  TGTemplate: TG_TEMPLATE,
  WXTemplate: WX_TEMPLATE,
  SCTemplate: SC_TEMPLATE,
  DiscordTemplate: DISCORD_TEMPLATE,
  LarkTemplate: LARK_TEMPLATE,
};
