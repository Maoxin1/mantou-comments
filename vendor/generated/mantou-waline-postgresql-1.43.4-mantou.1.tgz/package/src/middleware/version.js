// Modified 2026-10-05 for the local Mantou PostgreSQL-only derivative.
// Upstream notices are preserved in LICENSE and DERIVATION.md.
const pkg = require('../../package.json');
module.exports = () => async (ctx, next) => {
  ctx.set('x-waline-version', pkg.upstreamVersion);
  ctx.set('x-mantou-build', pkg.version);
  await next();
};
