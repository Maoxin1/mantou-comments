# Private local Waline PostgreSQL derivative

Base: @waline/vercel 1.43.4, official npm archive integrity sha512-g6qblq8i5H0ByDbsYRdPcsvauXicXfiLYhxIynwHpuYuawM1QuxAGkttQQgCOi+u960JFjbsQOmRzA0XHJfydw==
Derived identity: @mantou/waline-postgresql 1.43.4-mantou.1; modified 2026-10-05.
This is a modified package, not an official Waline release.

Only PostgreSQL storage and its base/MySQL/order inheritance helpers remain.
Cloudbase, Leancloud, Akismet, MongoDB, SQLite, MySQL and TiDB integrations/drivers
have been removed. The MySQL storage helper is retained solely because PostgreSQL
inherits it; no MySQL driver/configuration remains. Direct package entry throws.
The application's public entrypoint is separately disabled. No deployment or DB
connection is approved or implied by this package.

The x-waline-version header identifies the upstream protocol version; the
x-mantou-build header identifies the modified package. Controller, logic, storage
PostgreSQL helpers and bundled @waline/core files are preserved byte-for-byte.
See the generation script and manifest in the local parent project for all changes.

## Licensing hold
The upstream package.json and bundled core package.json say MIT, but both shipped
LICENSE files contain GPL version 2 and a Waline v2-or-later notice. Those LICENSE
files and the bundled core metadata are preserved unmodified. The derivative uses
SEE LICENSE IN LICENSE and makes no MIT-only licensing claim. The original
manifest is retained in the pinned source archive. Other dependencies retain their
own licenses; ua-parser-js declares AGPL-3.0-or-later. No public redistribution,
publishing, production deployment or license-compatibility claim is made. Resolve
licensing and corresponding-source requirements before distribution/deployment.

Upstream README is historical reference, not instructions to enable this build.
