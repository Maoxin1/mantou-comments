// Modified 2026-10-05 for the local Mantou PostgreSQL-only derivative.
// Upstream notices are preserved in LICENSE and DERIVATION.md.
'use strict';
throw new Error('Direct entry is disabled; use the separately reviewed isolated bootstrap');
